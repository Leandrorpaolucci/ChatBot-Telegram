<?php
$servername = "localhost";
$database = "usuarios_telegram";
$username = "root";
$password = "";
// create connection
$conexao = mysqli_connect($servername, $username, $password, $database);

?>
